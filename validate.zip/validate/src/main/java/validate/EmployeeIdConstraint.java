package validate;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class EmployeeIdConstraint implements ConstraintValidator<EmployeeId, String>
{

	public boolean isValid(String value, ConstraintValidatorContext context) {
		
		if(value.startsWith("E") || value.startsWith("e"))
		{
			return true;
		}
		return false;
	}

}
