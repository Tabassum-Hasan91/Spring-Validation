package validate;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Employee {
	
	//@NameValidator(message="Name should start with A")
	private String name;  
	
    @Size(min=1,message="password is required")  
    private String pass;
    
    @Pattern(regexp="\\d{10}$",message="Enter a 10 digit number")
    private String contactNo;
    
    @InvalidEmail(message="Email should end with niit.com")
    private String email;
    
    @EmployeeId(message="Emp id should start with E")
    private String empId; 
      
    
    
    public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getName() {  
        return name;  
    }  
    public void setName(String name) {  
        this.name = name;  
    }  
    public String getPass() {  
        return pass;  
    }  
    public void setPass(String pass) {  
        this.pass = pass;  
    }     

}
