package validate;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Constraint(validatedBy=EmailValidator.class)
@Retention(RUNTIME)
@Target({ FIELD })
public @interface InvalidEmail {
	
	String message() default "Invalid email";
	
	//represents group of constraints     
    public Class<?>[] groups() default {};  
    
//represents additional information about annotation  
    public Class<? extends Payload>[] payload() default {};  

}
