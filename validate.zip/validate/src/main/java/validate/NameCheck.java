package validate;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class NameCheck implements ConstraintValidator<NameValidator, String>
{

	public boolean isValid(String value, ConstraintValidatorContext context) {
		if(value.startsWith("a")||value.startsWith("A"))
		{
			return true;
		}
		return false;
	}

}
