package validate;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class EmailValidator implements ConstraintValidator<InvalidEmail, String>
{

	public boolean isValid(String value, ConstraintValidatorContext context) {
		
		if(value.endsWith("niit.com"))
		{
			return true;
		}
		
		return false;
	}

}
